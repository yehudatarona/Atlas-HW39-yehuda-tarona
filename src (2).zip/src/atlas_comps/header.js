import React from 'react';
import "../css_comps/atlas.css"
function Header(props){
  return(
    <header  className="container d-flex align-items-end  text-center justify-content-center"> 
    {/* <h1 className ="display-3 ">Country Info</h1> */}
     
    </header> 
  )
}

export default Header
